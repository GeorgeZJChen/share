<?php

require("../includes/AgileTeam10.php");

login($_POST["email"], $_POST["password"]);


?>

