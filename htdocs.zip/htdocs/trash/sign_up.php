
<?php
	session_start();

	require("../includes/AgileTeam10.php");

	head("Sign up");

?>
