
<?php
session_start();

require("../includes/AgileTeam10.php");

head("Sign in"); //header
p_sign_in(); //body

//Actions
if($_SERVER["REQUEST_METHOD"] == "POST") {
	//TODO: sanitize everything and send a hash for everything, like   $email = $_POST[md5(CONFIG_SITE_NAME.'USR')]
	login($_POST["email"], $_POST["password"]);
}

?>
