
<?php
	session_start();

	require("../includes/AgileTeam10.php");

	head("Home");
	p_home();

?>
