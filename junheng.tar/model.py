import torch
from torchvision import models
import torch.nn as nn

class GoNet(nn.Module):
    ''' Neural Network class
        Two stream model:
    ________
   |        | conv layers              Untrained Fully
   |Previous|------------------>|      Connected Layers
   | frame  |                   |    ___     ___     ___
   |________|                   |   |   |   |   |   |   |   fc4
               Pretrained       |   |   |   |   |   |   |    * (left)
               CaffeNet         |-->|fc1|-->|fc2|-->|fc3|--> * (top)
               Convolution      |   |   |   |   |   |   |    * (right)
               layers           |   |___|   |___|   |___|    * (bottom)
    ________                    |   (4096)  (4096)  (4096)  (4)
   |        |                   |
   | Current|------------------>|
   | frame  |
   |________|

    '''
    def __init__(self):
        super(GoNet, self).__init__()
        #caffenet = models.alexnet(pretrained=True)

        '''
        self.convnet = nn.Sequential(*list(caffenet.children())[:-1])
        for param in self.convnet.parameters():
            param.requires_grad = False
        '''

        #nn.Conv2d(in_channels, out_channels, kernel_size, stride=1, padding=0, dilation=1, groups=1, bias=True)

        self.features_low = nn.Sequential(
                nn.Conv2d(3,96,11,2),   # 109
                nn.BatchNorm2d(96),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(3, 2),   # 54,向下取整
                #nn.Conv2d(96, 256, 5, 1, groups=2), # 50
                nn.Conv2d(96, 256, 5, 1),
                nn.BatchNorm2d(256),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(3, 2), # 25
                nn.Conv2d(256, 192, 3, 1),  # 23
                nn.BatchNorm2d(192),
                nn.ReLU(inplace=True),
                #nn.Conv2d(192, 192, 3, 1, groups=2), # 21
                nn.Conv2d(192, 192, 3, 1),
                nn.BatchNorm2d(192),
                nn.ReLU(inplace=True),
                #nn.Conv2d(192, 128, 3, 1, groups=2)  # 19
                nn.Conv2d(192, 128, 3, 1),
        )

        self.features_high = nn.Sequential(
                nn.Conv2d(3,128,3),
                nn.Conv2d(128,128,3),
                nn.Conv2d(128,128,3,2),
                #nn.MaxPool2d(3, 2),
                nn.BatchNorm2d(128),
                nn.ReLU(inplace=True),
                nn.Conv2d(128,256,3),
                nn.Conv2d(256,256,3),
                nn.Conv2d(256,256,3,2),
                #nn.MaxPool2d(3, 2),
                nn.BatchNorm2d(256),
                nn.ReLU(inplace=True),
                nn.Conv2d(256,256,3),
                nn.Conv2d(256,256,3),
                nn.Conv2d(256,256,3),
                nn.Conv2d(256,256,3,2),
                #nn.MaxPool2d(3, 2),
                nn.BatchNorm2d(256),
                nn.ReLU(inplace=True),
                nn.Conv2d(256,128,3),
                nn.Conv2d(128,128,3),
                nn.BatchNorm2d(128),
                nn.ReLU(inplace=True),
                nn.Conv2d(128,128,2),
        )

        self.classifier = nn.Sequential(
                nn.Dropout(),
                nn.Linear(128*18*18*2, 4),
                # nn.ReLU(inplace=True),
                # nn.Dropout(),
                # nn.Linear(4096, 4096),
                # nn.ReLU(inplace=True),
                # nn.Dropout(),
                # nn.Linear(4096,4096),
                # nn.ReLU(inplace=True),
                # nn.Linear(4096, 4),
                )

        self.weight_init()

    def weight_init(self):
        for h in self.features_low.modules():
            if isinstance(h, nn.Conv2d):
                nn.init.kaiming_normal_(h.weight.data, mode='fan_out', nonlinearity='relu')
            elif isinstance(h, nn.BatchNorm2d):
                h.weight.data.fill_(1)
                h.bias.data.zero_()
        for j in self.features_high.modules():
            if isinstance(j, nn.Conv2d):
                nn.init.kaiming_normal_(j.weight.data, mode='fan_out', nonlinearity='relu')
            elif isinstance(j, nn.BatchNorm2d):
                j.weight.data.fill_(1)
                j.bias.data.zero_()
        for m in self.classifier.modules():
            # fully connected layers are weight initialized with
            # mean=0 and std=0.005 (in tracker.prototxt) and
            # biases are set to 1
            if isinstance(m, nn.Linear):
                m.bias.data.fill_(1)
                m.weight.data.normal_(0, 0.005)

    # feed forward through the neural net
    def forward(self, x, y):
        '''
        x1 = self.convnet(x)
        x1 = x1.view(x.size(0), 256*6*6)
        x2 = self.convnet(y)
        x2 = x2.view(x.size(0), 256*6*6)
        x = torch.cat((x1, x2), 1)
        x = self.classifier(x)
        return x

        a = self.features_high(x)
        b = self.features_low(x)
        print(a.shape)
        print(b.shape)
        '''
        #x1 = 0.3 * self.features_high(x) + 0.7 * self.features_low(x)
        x_low = self.features_low(x)
        x_high = self.features_high(x)
        x1 = 0.3 * x_high + 0.7 * x_low
        #x1 = self.view(x.size(0), 128*18*18)
        #x2 = 0.3 * self.features_high(y) + 0.7 * self.features_low(y)
        y_low = self.features_low(y)
        y_high = self.features_high(y)
        x2 = 0.3 * y_high + 0.7 * y_low
        #x2 = self.view(x.size(0), 128*18*18)
        x = torch.cat((x1, x2), 1)
        x = self.classifier(x)
        return x
