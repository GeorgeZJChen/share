# -*- coding: utf-8
from __future__ import print_function
import torch
import torch.nn.functional as F
import torch.nn as nn
from collections import OrderedDict

class ActivatedBatchNorm(nn.Module):
    def __init__(self, num_features, activation='relu', slope=0.01, **kwargs):
        super(ActivatedBatchNorm, self).__init__()
        self.bn = nn.BatchNorm2d(num_features, **kwargs)
        if activation == 'relu':
            self.act = nn.ReLU(inplace=True)
        elif activation == 'leaky_relu':
            self.act = nn.LeakyReLU(negative_slope=slope, inplace=True)
        elif activation == 'elu':
            self.act = nn.ELU(inplace=True)
        elif activation == 'relu6':
            self.act = nn.ReLU6(inplace=True)
        else:
            self.act = None

    def forward(self, x):
        x = self.bn(x)
        if self.act:
            x = self.act(x)
        return x

class ExpandedConv(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, dilation=1,
                 expand_ratio=6, skip_connection=False):
        super(ExpandedConv, self).__init__()

        self.stride = stride
        self.kernel_size = 3
        self.dilation = dilation
        self.expand_ratio = expand_ratio
        self.skip_connection = skip_connection
        middle_channels = in_channels * expand_ratio

        if self.expand_ratio != 1:
            # pointwise
            self.expand = nn.Sequential(OrderedDict(
                [('conv', nn.Conv2d(in_channels, middle_channels, 1, bias=False)),
                 ('bn', nn.BatchNorm2d(middle_channels)),
                 ('relu', nn.ReLU(inplace=True))
                 ]))

        # depthwise
        self.depthwise = nn.Sequential(OrderedDict(
            [('conv', nn.Conv2d(middle_channels, middle_channels, 3, stride, dilation, dilation, groups=middle_channels, bias=False)),
             ('bn', nn.BatchNorm2d(middle_channels)),
             ('relu', nn.ReLU(inplace=True))
             ]))

        # project
        self.project = nn.Sequential(OrderedDict(
            [('conv', nn.Conv2d(middle_channels, out_channels, 1, bias=False)),
             ('bn', nn.BatchNorm2d(out_channels))
             ]))

    def forward(self, x):
        if self.expand_ratio != 1:
            residual = self.project(self.depthwise(self.expand(x)))
        else:
            residual = self.project(self.depthwise(x))

        if self.skip_connection:
            outputs = x + residual
        else:
            outputs = residual
        return outputs


class MobileNetV2(nn.Module):
    def __init__(self, pretrained=False, model_path='../model/mobilenetv2_encoder/model.pth'):
        super(MobileNetV2, self).__init__()

        self.conv = nn.Conv2d(3, 32, 3, stride=2, padding=1, bias=False)
        self.bn = nn.BatchNorm2d(32)
        self.relu = nn.ReLU(inplace=True)

        self.block0 = ExpandedConv(32, 16, expand_ratio=1)

        self.block1 = ExpandedConv(16, 24, stride=2)
        # self.block2 = ExpandedConv(24, 24, skip_connection=True)

        self.block3 = ExpandedConv(24, 32, stride=2)
        # self.block4 = ExpandedConv(32, 32, skip_connection=True)
        # self.block5 = ExpandedConv(32, 32, skip_connection=True)

        # self.block6 = ExpandedConv(32, 64, stride=2)
        # self.block7 = ExpandedConv(64, 64, skip_connection=True)
        # self.block8 = ExpandedConv(64, 64, skip_connection=True)
        # self.block9 = ExpandedConv(64, 64, skip_connection=True)
        self.block6 = ExpandedConv(32, 48, stride=2)
        # self.block7 = ExpandedConv(48, 48, skip_connection=True)
        # self.block8 = ExpandedConv(48, 48, skip_connection=True)
        # self.block9 = ExpandedConv(48, 48, skip_connection=True)

        # self.block10 = ExpandedConv(64, 96, stride=2)               # 改变stride
        # self.block11 = ExpandedConv(96, 96, skip_connection=True)
        # self.block12 = ExpandedConv(96, 96, skip_connection=True)
        # self.block10 = ExpandedConv(48, 64, stride=2)               # 改变stride
        # self.block11 = ExpandedConv(64, 64, skip_connection=True)
        # self.block12 = ExpandedConv(64, 64, skip_connection=True)

        # self.block13 = ExpandedConv(96, 160, stride=2)
        # self.block14 = ExpandedConv(160, 160, skip_connection=True)
        # self.block15 = ExpandedConv(160, 160, skip_connection=True)
        # self.block16 = ExpandedConv(160, 320)


def mobilenet_v2_unet(name, pretrained=False):
    m = MobileNetV2(pretrained=False, model_path='../model/mobilenetv2_encoder/model.pth')

    layer0 = nn.Sequential(m.conv, m.bn, m.relu, m.block0)
    layer0.out_channels = 16

    # layer1 = nn.Sequential(m.block1, m.block2)
    layer1 = nn.Sequential(m.block1)
    layer1.out_channels = 24

    # layer2 = nn.Sequential(m.block3, m.block4)
    layer2 = nn.Sequential(m.block3)
    layer2.out_channels = 32

    # layer3 = nn.Sequential(m.block6,m.block7)
    layer3 = nn.Sequential(m.block6)
    layer3.out_channels = 48

    # layer4 = nn.Sequential(m.block10,m.block11,m.block12)
    # layer4 = nn.Sequential(m.block10)
    # layer4.out_channels = 96

    return [layer0, layer1, layer2, layer3]

class DecoderUnetUpsample(nn.Module):
    def __init__(self, in_channels, middle_channels, out_channels):
        super(DecoderUnetUpsample, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, middle_channels, 1, bias=False),
            ActivatedBatchNorm(middle_channels, activation='relu'),
            )
            # nn.PixleShuffle(upscale_factor=2),
            # nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False), # 最近邻（nearest），线性插值（linear），双线性插值（bilinear），三次线性插值（trilinear），默认是最近邻（nearest）
            
        self.block2 = nn.Sequential(
            # First design
            nn.Conv2d(middle_channels, middle_channels, 3, groups=middle_channels, padding=1, bias=False),
            ActivatedBatchNorm(middle_channels, activation='relu'),

            nn.Conv2d(middle_channels, out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            # First end
            
            # nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
            # ActivatedBatchNorm(out_channels, activation='relu')
        )

    def forward(self, *args):
        if len(args) > 1:
            x = torch.cat(args, 1)
        else:
            x = args[0]
        x = self.block(x)
        x = F.interpolate(x, scale_factor=2, mode='bilinear', align_corners=False)
        return self.block2(x)

class EncoderDecoderNet(nn.Module):
    def __init__(self, output_channels=2, enc_type='mv2', dec_type='unet_scse',
                 num_filters=12, pretrained=False):
        super(EncoderDecoderNet, self).__init__()
        self.output_channels = output_channels

        encoder = mobilenet_v2_unet(enc_type, pretrained)
        Decoder = DecoderUnetUpsample

        self.encoder1 = encoder[0]
        self.encoder2 = encoder[1]
        self.encoder3 = encoder[2]
        self.encoder4 = encoder[3]
        # self.encoder5 = encoder[4]

        self.pool = nn.MaxPool2d(2, 2)

        self.center = Decoder(self.encoder4.out_channels, num_filters * 8 * 2, num_filters * 6)
        # self.decoder5 = Decoder(self.encoder5.out_channels + num_filters * 8, num_filters * 12 * 2, num_filters * 6)
        self.decoder4 = Decoder(self.encoder4.out_channels + num_filters * 6, num_filters * 6 * 2, num_filters * 4)
        self.decoder3 = Decoder(self.encoder3.out_channels + num_filters * 4, num_filters * 4 * 2, num_filters * 3)
        self.decoder2 = Decoder(self.encoder2.out_channels + num_filters * 3, num_filters * 3 * 2, num_filters * 2)
        self.decoder1 = Decoder(self.encoder1.out_channels + num_filters * 2, num_filters * 2 * 2, num_filters)
        self.logits = nn.Sequential(
            nn.Conv2d(num_filters * (4 + 3 + 2 + 1), 10, kernel_size=1, padding=0, bias=False),
            ActivatedBatchNorm(10),
            nn.Conv2d(10, self.output_channels, kernel_size=1, bias=False)
            # nn.Conv2d(num_filters * (4 + 3 + 2 + 1), self.output_channels, kernel_size=1, bias=False)
        )


    def forward(self, x):
        img_size = x.shape[2:]
        img_size = (img_size[0], img_size[1])

        e1 = self.encoder1(x) # (56 * 56)
        e2 = self.encoder2(e1) # (56 * 56)
        e3 = self.encoder3(e2) # (28 * 28)
        e4 = self.encoder4(e3) # (14 * 14)
        # e5 = self.encoder5(e4) # (7 * 7)

        c = self.center(self.pool(e4)) # (7 * 7)
        # e1_up = e1
        # e5 = self.conv_1_1(e5)

        # d5 = self.decoder5(c, e5) # (14 * 14)
        d4 = self.decoder4(c, e4) # (28 * 28)
        d3 = self.decoder3(d4, e3) # (56 * 56)
        d2 = self.decoder2(d3, e2) # (112 * 112)
        d1 = self.decoder1(d2, e1) # (224 * 224)


        # u5 = F.interpolate(d5, scale_factor=16, mode='bilinear', align_corners=False)
        u4 = F.interpolate(d4, scale_factor=8, mode='bilinear', align_corners=False)
        u3 = F.interpolate(d3, scale_factor=4, mode='bilinear', align_corners=False)
        u2 = F.interpolate(d2, scale_factor=2, mode='bilinear', align_corners=False)

        # Hyper column
        d = torch.cat((d1, u2, u3, u4), 1)
        logits = self.logits(d)

        return logits

EncoderDecoderNet()