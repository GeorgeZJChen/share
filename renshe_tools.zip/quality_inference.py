# -*- coding: utf-8
import os
import cv2
import numpy as np
import argparse

import torch
from utils import minmax_normalize, meanstd_normalize, quaternion_2_ypr, str2bool
from metrics import compute_features_rate
from collections import namedtuple

Batch = namedtuple('Batch', ['data'])
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def draw_text(img, text, org=(10, 10)):
    font = cv2.FONT_HERSHEY_SIMPLEX 
    fontScale = 1
    color = (255, 0, 0)
    thickness = 1
    cv2.putText(img, text, org, font, fontScale, color, thickness, cv2.LINE_AA)

def load_occ_model():
    from occ_model import EncoderDecoderNet
    model = EncoderDecoderNet(output_channels=1,enc_type='mv2',dec_type='unet_upsample',num_filters=12)
    model = torch.nn.DataParallel(model)
    model.load_state_dict(torch.load('model/occ_size_96_9-17.pth'))
    model = model.to(device)
    model.eval()
    return model

def load_blur_model():
    from blur_mb import Model
    model = Model(net_type='MobileNet', n_class=1)
    model = torch.nn.DataParallel(model).to(device)
    model.load_state_dict(torch.load('model/blur_mv_10-8.pth'), strict=False)
    model = model.to(device)
    model.eval()
    return model

def load_headpose_model():
    # from hdmodel import resnet18
    from hdmodel import MobileNet
    # model = resnet18()
    model = MobileNet()
    model = torch.nn.DataParallel(model).to(device)
    # model.load_state_dict(torch.load('model/headpose_resnet_10-22.pth'), strict=False)
    model.load_state_dict(torch.load('model/headpose_mobilenet.pth'), strict=False)
    model = model.to(device)
    model.eval()
    return model

def load_lmk_model():
    import caffe
    net = caffe.Net('model/lmk_pfld_mv2_tiny_519_merged.prototxt', \
        'model/lmk_pfld_mv2_tiny_519_merged.caffemodel', caffe.TEST)
    return net

def load_lmk_mx_model():
    import mxnet as mx
    sym, arg, aux = mx.model.load_checkpoint("", 0)
    model = mx.mod.Module(symbol=sym, label_names=None)
    model.bind(for_training=False, data_shapes=[('data', (1,3,112,112))], label_shapes=None)
    model.set_params(arg, aux)
    return model

def computeRate(label, pred, points):

    # 嘴巴区域
    pts_mouth = [np.vstack(cv2.convexHull(np.array(points[86:106])))]
    # rate_mouth = compute_rate(pred, label, pts_mouth, scalePts=4)
    rate_mouth, rect_m = compute_features_rate(pred, label, pts_mouth, points[:33], ptype=0, scalePts=5)

    # 左眼区域
    pts_eye_left = np.vstack(cv2.convexHull(np.array(points[42:52])))
    # pts_brow_left = np.vstack(cv2.convexHull(np.array(points[33:42])))
    # pts_left = np.vstack(cv2.convexHull(np.array(points[33:53])))
    # rate_eye_left = compute_rate(pred, label, [pts_eye_left,pts_brow_left], [pts_left], scalePts=0)
    rate_eye_left, rect_l = compute_features_rate(pred, label, [pts_eye_left], points[:33], ptype=1, scalePts=3)

    # 右眼区域
    pts_eye_right = np.vstack(cv2.convexHull(np.array(points[61:71])))
    # pts_brow_right = np.vstack(cv2.convexHull(np.array(points[52:61])))
    # pts_right = np.vstack(cv2.convexHull(np.array(points[52:71])))
    # rate_eye_right = compute_rate(pred, label, [pts_eye_right,pts_brow_right], [pts_right], scalePts=0)
    rate_eye_right, rect_r = compute_features_rate(pred, label, [pts_eye_right], points[:33], ptype=2, scalePts=3)

    # 额头区域, 两个眉毛的上方
    rate_forehead, rect_f = compute_features_rate(pred, label, [points[33:71]], None, ptype=3, scalePts=0)

    # 鼻子区域
    pts_nose = [points[72:75],points[76:81],points[82:86]]
    rate_nose, rect_n = compute_features_rate(pred, label, pts_nose, None, ptype=4, scalePts=0)

    # 下巴区域
    chin_pts = np.vstack([points[105:106],points[12:17],points[29:33]])
    chin_pts = np.vstack(cv2.convexHull(chin_pts))
    rate_chin, rect_c = compute_features_rate(pred, label, [chin_pts], None, ptype=5, scalePts=0)

    # 左脸颊区域
    face_left_pts = np.vstack([points[48:48],points[76:78],points[3:11]])
    face_left_pts = np.vstack(cv2.convexHull(face_left_pts))
    rate_face_left, rect_fl = compute_features_rate(pred, label, [face_left_pts], None, ptype=6, scalePts=0)

    # 右脸颊区域
    face_right_pts = np.vstack([points[67:68],points[82:84],points[19:27]])
    face_right_pts = np.vstack(cv2.convexHull(face_right_pts))
    rate_face_right, rect_fr = compute_features_rate(pred, label, [face_right_pts], None, ptype=7, scalePts=0)


    return rate_mouth, rate_eye_left, rate_eye_right, rate_nose, rate_chin, rate_face_left, rate_face_right, rate_forehead

def crop_img(img, bbox, scale=1, isOcc=False):
    x1, y1, x2, y2 = bbox
    if isOcc:
        y1 -= (y2 - y1) / 5
    x1, y1, x2, y2 = int(x1),int(y1),int(x2),int(y2)
    w, h = x2-x1, y2-y1
    hw = int( max(w, h) * scale )
    x1 -= int((hw - w) / 2)
    y1 -= int((hw - h) / 2)
    x2, y2 = x1+hw, y1+hw

    img_border = cv2.copyMakeBorder(img, hw, hw, hw, hw, cv2.BORDER_CONSTANT)
    img_croped = img_border[hw+y1:y2+hw, hw+x1:x2+hw]

    return img_croped, (x1, y1, x2, y2)

def blur_infer(model, img):
    img = cv2.resize(img, (96, 96))

    img = minmax_normalize(img)
    img = meanstd_normalize(img, mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])

    img = img.transpose(2, 0, 1)

    img = torch.FloatTensor([img]).to(device)
    preds = model(img)
    preds_np = preds.detach().cpu().numpy()

    return preds_np[0]

def head_infer(model, img):
    img=cv2.resize(img, (64, 64))

    img = minmax_normalize(img)
    img = meanstd_normalize(img, mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])

    img = img.transpose(2, 0, 1)

    img = torch.FloatTensor([img]).to(device)
    preds = model(img)
    preds_np = preds.detach().cpu().numpy()

    return preds_np[0]

def occ_infer(model, img):
    # img=cv2.resize(img, (64, 64),interpolation=cv2.INTER_CUBIC)
    img = cv2.resize(img, (96, 96))

    img = minmax_normalize(img)
    img = meanstd_normalize(img, mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])

    img = img.transpose(2, 0, 1)
    img = torch.FloatTensor([img]).to(device)
    # preds = model.module.tta(image, net_type='unet')
    preds = model(img)
    preds_np = preds.detach().cpu().numpy()

    preds_np = np.squeeze(preds_np, axis=(1,))
    pos_index = preds_np > 0.5
    preds_np[pos_index] = 1
    preds_np[~pos_index] = 0

    return preds_np[0]*255

def occ_handle(model, image, pts):
    img, sbbox = crop_img(image, (min(pts[:,0]), min(pts[:,1]), max(pts[:,0]), max(pts[:, 1])), scale=1.1, isOcc=True)
    pre_mask = occ_infer(model, img)

    scale_pts = []
    scale = 96 / (sbbox[2]-sbbox[0])
    for pt in pts:
        x = int((pt[0]-sbbox[0])*scale)
        y = int((pt[1]-sbbox[1])*scale)
        scale_pts.append([x, y])

    pts = np.asarray(scale_pts)

    label = np.zeros((96, 96),dtype=np.uint8)
    pts_all = cv2.convexHull(pts)
    cv2.fillPoly(label, [pts_all], (255,255,255))

    occ_ret = computeRate(label, pre_mask, pts)

    # image[:96, :96, :] = cv2.cvtColor(pre_mask, cv2.COLOR_GRAY2BGR)

    return occ_ret

def lmk_handle(net, image, bbox):
    img, sbbox = crop_img(image, bbox, scale=1.2)
    img = cv2.resize(img, (112,112))
    img = np.transpose(img, (2,0,1))
    img = img[np.newaxis, :] 
    img = img / 256 - 0.5
    
    net.blobs['data'].data[...] = img
    ret = net.forward()
    out = net.blobs['landmark_predict'].data[0]
    
    pts = []
    for i in range(106):
        x = sbbox[0] + out[2*i] * (sbbox[2]-sbbox[0]) / 112
        y = sbbox[1] + out[2*i+1] * (sbbox[3]-sbbox[1]) / 112
        pts.append([x, y])
    return np.asarray(pts).astype(np.int)

def lmk_mx_handle(model, image, bbox):
    img, sbbox = crop_img(image, bbox, scale=1.2)
    img = cv2.resize(img, (112,112))
    img = np.transpose(img, (2,0,1))
    img = img[np.newaxis, :] 
    img = img / 256 - 0.5
    
    model.forward(Batch([mx.nd.array(img)]))
    out = model.get_outputs()[0][0].asnumpy()
    
    pts = []
    for i in range(106):
        x = sbbox[0] + out[2*i] * (sbbox[2]-sbbox[0]) / 112
        y = sbbox[1] + out[2*i+1] * (sbbox[3]-sbbox[1]) / 112
        pts.append([x, y])
    return np.asarray(pts).astype(np.int)

def light_handle(img_croped):
    img_hsv = cv2.cvtColor(img_croped, cv2.COLOR_BGR2HSV)
    light_score = np.mean(img_hsv[:, :, 2])
    return light_score

def main(args):
    blur_model = load_blur_model()
    hp_model = load_headpose_model()
    occ_model = load_occ_model()
    # lmk_model = load_lmk_model()
    lmk_model = load_lmk_mx_model()
    with open(args.filelist, 'r') as f:
        for k, line in enumerate(f.readlines()):
            ls = line.strip().split(' ')

            name = ls[0]
            img = cv2.imread('F:/pingan/headPose/data/'+name)
            img = img[..., ::-1]

            x1, y1, x2, y2 = int(float(ls[1])),int(float(ls[2])),int(float(ls[3])),int(float(ls[4]))

            # light inference
            img_croped, _ = crop_img(img, (x1, y1, x2, y2), 0.8)
            light_score = light_handle(img_croped)

            img_croped, _ = crop_img(img, (x1, y1, x2, y2), 1.1)
            # blur inference
            blur_score = blur_infer(blur_model, img_croped)

            # head pose inference
            hp_pred = head_infer(hp_model, img_croped)
            hp_pred = quaternion_2_ypr(*hp_pred)
            hp_pred[1] = -hp_pred[1]
            
            # occ inference
            # pts = lmk_handle(lmk_model, img, (x1, y1, x2, y2))
            pts = lmk_mx_handle(lmk_model, img, (x1, y1, x2, y2))

            occ_ret = occ_handle(occ_model, img, pts)
            rate_mouth, rate_eye_left, rate_eye_right, rate_nose, rate_chin, rate_face_left, rate_face_right, rate_forehead = occ_ret

            print('===============================================')
            print('[INFO] Mouth    :', rate_mouth)
            print('[INFO] Eye left :', rate_eye_left)
            print('[INFO] Eye right:', rate_eye_right)
            print('[INFO] Nose     :', rate_nose)
            print('[INFO] Chin     :', rate_chin)
            print('[INFO] Face left:', rate_face_left)
            print('[INFO] FaceRight:', rate_face_right)
            print('[INFO] ForeHead :', rate_forehead)
            print('[INFO] Light    :', light_score)
            print('[INFO] Blur     :', blur_score)
            print('[INFO] Head Pose:', hp_pred)
            print('===============================================\n')

            draw_text(img, "Light:"+str(light_score), (10, 20))
            draw_text(img, "Blur:"+str(blur_score), (10, 40))
            draw_text(img, "Pose:"+str(hp_pred), (10, 60))

            cv2.imwrite("ddg_test.jpg", img)
            break
            # cv2.imshow('img', img)
            # cv2.waitKey(0)


if __name__=='__main__':
    parser = argparse.ArgumentParser(description='renshe inference pipeline')
    parser.add_argument('-f', '--filelist', type=str,
                        help='image file list paths')
    # parser.add_argument('-m', '--mode', default='high', type=str, help='high/medium/low/other mode')
    # parser.add_argument('--savedir', default='one', type=str)

    args = parser.parse_args()
    main(args)