from __future__ import division
from __future__ import print_function
import numpy as np
import cv2
import warnings
warnings.filterwarnings('ignore', category=RuntimeWarning)


def compute_ious(pred, label, classes, ignore_index=255, only_present=True):
    pred[label == ignore_index] = 0
    ious = []
    for c in classes:
        label_c = label == c
        if only_present and np.sum(label_c) == 0:
            ious.append(np.nan)
            continue
        pred_c = pred == c
        intersection = np.logical_and(pred_c, label_c).sum()
        union = np.logical_or(pred_c, label_c).sum()
        if union != 0:
            ious.append(intersection / union)
    return ious if ious else [1]


def compute_iou_batch(preds, labels, classes=None):
    iou = np.nanmean([np.nanmean(compute_ious(pred, label, classes)) for pred, label in zip(preds, labels)])
    return iou

def compute_percentages(pred, label, classes, ignore_index=255, only_present=True):
    pred[label == ignore_index] = 0
    pers = []
    for c in classes:
        label_c = label == c
        if only_present and np.sum(label_c) == 0:
            pers.append(np.nan)
            continue
        pred_c = pred == c
        intersection = np.logical_and(pred_c, label_c).sum()
        # union = np.logical_or(pred_c, label_c).sum()
        s = np.sum(label_c)
        if s != 0:
            pers.append(intersection / s)
    return pers if pers else [1]

def compute_percentage_batch(preds, labels, classes=None):
    per = np.nanmean([np.nanmean(compute_percentages(pred, label, classes)) for pred, label in zip(preds, labels)])
    return per

# 从一行中获取lmk点
def getPoints(string, scale=1):
    points = []
    pts = string.strip().split(' ')
    for i in range(0, 106*2, 2):
        x, y = int(float(pts[i]) / scale), int(float(pts[i+1]) / scale)
        points.append((x, y))

    return np.asarray(points)

# 获取额头以上部位的凸包点集合, pts_all 点是从右边开始, s左右扩充的像素值
def get_forehead_pts(pts_all, s=2, img_size=96):
    pts = []
    l_idx, r_idx = 0, 0
    l_x, r_x = img_size, 0
    for i, pt in enumerate(pts_all):
        pt_x = pt[0][0]
        if pt_x < l_x:
            l_idx, l_x = i, pt_x
        if pt_x > r_x:
            r_idx, r_x = i, pt_x

    x1, y1, x2, y2 = pts_all[l_idx][0][0], pts_all[l_idx][0][1], pts_all[r_idx][0][0], pts_all[r_idx][0][1]
    if r_idx < l_idx:
        pts.append(pts_all[l_idx:])
        pts.append(pts_all[r_idx::-1])
    else:
        pts.append(pts_all[l_idx:r_idx+1])
    pts.append(np.array([ [[x2+s,y2]], [[x2+s,0]], [[x1-s,0]], [[x1-s,y1]] ]))
    return np.vstack(pts)


def iou_analyzer(preds, labels, tods):
    mIoU = np.nanmean([np.nanmean(compute_ious(pred, label, [1, 2, 3, 4])) for pred, label in zip(preds, labels)])
    print(f'Valid mIoU: {mIoU:.3f}\n')

    class_names = ['car', 'person', 'signal', 'road']
    tod_names = ['morning', 'day', 'night']
    iou_dict = {tod_name: dict(zip(class_names, [[] for _ in range(len(class_names))])) for tod_name in tod_names}
    for pred, label, tod in zip(preds, labels, tods):
        iou_per_class = compute_ious(pred, label, [1, 2, 3, 4])
        for iou, class_name in zip(iou_per_class, class_names):
            iou_dict[tod][class_name].append(iou)

    for tod_name in tod_names:
        print(f'\n---{tod_name}---')
        for k, v in iou_dict[tod_name].items():
            print(f'{k}: {np.nanmean(v):.3f}')

    print('\n---ALL---')
    for class_name in class_names:
        ious = []
        for tod_name in tod_names:
            ious += iou_dict[tod_name][class_name]
        print(f'{class_name}: {np.nanmean(ious):.3f}')


def get_rectangle(points, scalePts, ptype=0):
    pre_size = 96
    minx = miny = float('inf')
    maxx = maxy = 0
    for pts in points:
        for x, y in pts:
            if minx > x:
                minx = x
            if maxx < x:
                maxx = x
            if miny > y:
                miny = y
            if maxy < y:
                maxy = y
    if ptype == 0 or ptype >= 4:
        minx = max(minx-scalePts, 0)
        miny = max(miny-scalePts, 0)
        maxx = min(maxx+scalePts,pre_size-1)
        maxy = min(maxy+scalePts,pre_size-1)
    elif ptype == 1:
        miny = max(miny-scalePts, 0)
        maxx = min(maxx+scalePts,pre_size-1)
        maxy = min(maxy+scalePts,pre_size-1)
    elif ptype == 2:
        minx = max(minx-scalePts, 0)
        miny = max(miny-scalePts, 0)
        maxy = min(maxy+scalePts,pre_size-1)
    elif ptype == 3:
        minx = max(minx-scalePts, 0)
        maxx = min(maxx+scalePts,pre_size-1)
        maxy = min(miny+scalePts,pre_size-1)
        miny = 0

    return (minx,miny,maxx,maxy)


def cross_point(p1, p2, p3, isrow=True):#计算交点函数
    k1 = (p2[1]-p1[1]) / (p2[0]-p1[0])
    b1 = p1[1] - p1[0]*k1

    # l2是一条水平直线
    if isrow:
        return ((p3[1]-b1)//k1, p3[1])
    else:
        return (p3[0], p3[0]*k1+b1)

def cross_k_b(p1, p2):
    if p2[1]-p1[1]==0 or p2[0]-p1[0]==0:
        return None, None
    k1 = (p2[1]-p1[1]) / (p2[0]-p1[0])
    b1 = p1[1] - p1[0]*k1
    return k1, b1


def get_inner_line(rect, points):
    pts_left = []
    pts_right = []
    for i,p in enumerate(points):
        if p[0]>=rect[0] and p[0]<=rect[1] and p[1]>=rect[2] and p[1]<=rect[3]:
            if i < 17:
                pts_left.append(p)
            else:
                pts_right.append(p)
    
    k1, b1, k2, b2 = None, None, None, None
    if len(pts_left) > 1:
        # p1 = cross_point(pts_left[0], pts_left[-1], rect[:2], isrow=False)
        # p2 = cross_point(pts_left[0], pts_left[-1], rect[2:], isrow=True)
        k1, b1 = cross_k_b(pts_left[0], pts_left[-1])
    if len(pts_right) > 1:
        # p3 = cross_point(pts_right[0], pts_right[-1], rect[2:], isrow=True)
        # p4 = cross_point(pts_right[0], pts_right[-1], rect[2:], isrow=False)
        # k2, b2 = cross_k_b(pts_right[0], pts_right[-1]) # new landmark
        k2, b2 = cross_k_b(pts_right[-1], pts_right[0])

    return k1, b1, k2, b2

# https://blog.csdn.net/xiaoyw71/article/details/79952520 
def GetAreaOfPolyGonbyVector(points):
    # 基于向量叉乘计算多边形面积
    area = 0
    if(len(points)<3):
         raise Exception("error")

    for i in range(0,len(points)-1):
        p1 = points[i]
        p2 = points[i + 1]

        triArea = (p1[0]*p2[1] - p2[0]*p1[1])/2
        area += triArea
    return abs(area)


def compute_features_rate(preds, labels, points, pts_33=None, ptype=0, scalePts=0):

    rect = get_rectangle(points, scalePts, ptype)
    x1, y1, x2, y2 = rect
    s = (x2-x1) * (y2-y1)
    # min size 5*5
    min_size = 5*5 if ptype <= 3 else 10*10
    if s < min_size:
        return 0, rect

    pred = preds[y1:y2, x1:x2]

    if 0 <= ptype <= 2:
        # 填充嘴巴、眼睛区域
        if ptype == 0:
            cv2.fillPoly(preds, points, (200,200,200))
            s -= cv2.contourArea(points[0])
        
        # 获取在矩形内的左右两条线段
        k1, b1, k2, b2 = get_inner_line(rect, pts_33)

        # 判断点是否在线段的左下方、右下方
        for i in range(x2-x1):
            for j in range(y2-y1):
                if k1 is not None:
                    pt = (i+x1)*k1+b1
                    if (k1<0 and pt>j+y1) or (k1>0 and pt<j+y1):
                        pred[j][i] = 128
                        s -= 1
                if k2 is not None:
                    pt = (i+x1)*k2+b2
                    if (k2>0 and pt>j+y1) or (k2<0 and pt<j+y1):
                        pred[j][i] = 128
                        s -= 1
    
        pred_0_s = pred == 0
        s_pred = np.sum(pred_0_s)
        return s_pred / s, rect

    elif 3 <= ptype <= 4:
        pred_0_s = pred == 0
        s_pred = np.sum(pred_0_s)
        return s_pred / s, rect

    elif ptype >= 5:
        mask = np.ones((y2-y1, x2-x1))
        points[0][:,0] -= x1
        points[0][:,1] -= y1
        cv2.fillPoly(mask, points, (0, 0, 0))
        pred_mask = pred + mask
        pred_0_s = pred_mask == 0
        s_pred = np.sum(pred_0_s)
        s = cv2.contourArea(points[0])

        return s_pred / s, rect


def isRayIntersectsSegment(poi,s_poi,e_poi): #[x,y] [lng,lat]
    #输入：判断点，边起点，边终点，都是[lng,lat]格式数组
    if s_poi[1]==e_poi[1]: #排除与射线平行、重合，线段首尾端点重合的情况
        return False
    if s_poi[1]>poi[1] and e_poi[1]>poi[1]: #线段在射线上边
        return False
    if s_poi[1]<poi[1] and e_poi[1]<poi[1]: #线段在射线下边
        return False
    if s_poi[1]==poi[1] and e_poi[1]>poi[1]: #交点为下端点，对应spoint
        return False
    if e_poi[1]==poi[1] and s_poi[1]>poi[1]: #交点为下端点，对应epoint
        return False
    if s_poi[0]<poi[0] and e_poi[1]<poi[1]: #线段在射线左边
        return False

    xseg=e_poi[0]-(e_poi[0]-s_poi[0])*(e_poi[1]-poi[1])/(e_poi[1]-s_poi[1]) #求交
    if xseg<poi[0]: #交点在射线起点的左侧
        return False
    return True  #排除上述情况之后

def isPoiWithinPoly(poi,poly):
    #输入：点，多边形三维数组
    #poly=[[[x1,y1],[x2,y2],……,[xn,yn],[x1,y1]],[[w1,t1],……[wk,tk]]] 三维数组

    #可以先判断点是否在外包矩形内 
    #if not isPoiWithinBox(poi,mbr=[[0,0],[180,90]]): return False
    #但算最小外包矩形本身需要循环边，会造成开销，本处略去
    sinsc=0 #交点个数
    for epoly in poly: #循环每条边的曲线->each polygon 是二维数组[[x1,y1],…[xn,yn]]
        for i in range(len(epoly)-1): #[0,len-1]
            s_poi=epoly[i]
            e_poi=epoly[i+1]
            if isRayIntersectsSegment(poi,s_poi,e_poi):
                sinsc+=1 #有交点就加1

    return True if sinsc%2==1 else  False

def compute_rate(preds, labels, points1, points2=None, only_present=False, scalePts=3):
    if len(preds.shape) == 4:
        return np.nanmean([compute_rate(pred, label, points1, points2, scalePts) for pred, label in zip(preds, labels)])
    else:
        x1, y1, x2, y2 = get_rectangle(points1, scalePts)
        s = (x2-x1) * (y2-y1)
        # min size 10*10
        if s < (scalePts*3)**2:
            return 0
        total_size = 0
        neg_size = 0

        for x in range(x1, x2):
            for y in range(y1, y2):
                tg = isPoiWithinPoly((x,y), points1)
                if not tg:
                    if points2 is not None:
                        if isPoiWithinPoly((x, y), points2):
                            total_size += 1
                            if not preds[y][x]:
                                neg_size += 1
                    else:
                        total_size += 1
                        if not preds[y][x]:
                            neg_size += 1
        if total_size < 10:
            return 0
        else:
            return neg_size / total_size

if __name__=='__main__':
    import time
    poly = [[(i+1,i+2) for i in range(50)]]
    poi = (0,2)
    stime = time.time()
    for i in range(64):
        for j in range(64):
            isPoiWithinPoly((i,j), poly)
    print(time.time()-stime)