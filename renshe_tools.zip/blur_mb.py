
import torch
import torch.nn as nn

class MobileNet(nn.Module):
    def __init__(self, n_class=1):
        super(MobileNet, self).__init__()

        def conv_bn(inp, oup, stride):
            return nn.Sequential(
                nn.Conv2d(inp, oup, 3, stride, 1, bias=False),
                nn.BatchNorm2d(oup),
                nn.ReLU(inplace=True)
            )

        def conv_dw(inp, oup, stride):
            return nn.Sequential(
                nn.Conv2d(inp, inp, 3, stride, 1, groups=inp, bias=False),
                nn.BatchNorm2d(inp),
                nn.ReLU(inplace=True),
    
                nn.Conv2d(inp, oup, 1, 1, 0, bias=False),
                nn.BatchNorm2d(oup),
                nn.ReLU(inplace=True),
            )

        self.model = nn.Sequential(
            conv_bn(  3,  32, 2), 
            conv_dw( 32,  64, 2),
            conv_dw( 64, 128, 2),
            conv_dw(128, 128, 2),
            # conv_dw(128, 256, 2),
            # conv_dw(256, 256, 1),
            # conv_dw(256, 512, 2),
            # conv_dw(512, 512, 1),
            # conv_dw(512, 512, 1),
            # conv_dw(512, 512, 1),
            # conv_dw(512, 512, 1),
            # conv_dw(512, 512, 1),
            # conv_dw(512, 1024, 2),
            # conv_dw(1024, 1024, 1),
            nn.AvgPool2d(6),
        )
        # building classifier
        self.classifier = nn.Sequential(nn.Linear(128, n_class), nn.Sigmoid())

    def forward(self, x):
        x = self.model(x)
        x = x.view(-1, 128)
        x = self.classifier(x)
        return x

class Model(nn.Module):
    def __init__(self, net_type='ShuffleNetV2', **kwargs):
        super().__init__()
        self.model = MobileNet(**kwargs)

    def forward(self, x):
        return self.model(x)

