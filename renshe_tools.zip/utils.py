
import math
import argparse
import numpy as np

def minmax_normalize(img, norm_range=(0, 1), orig_range=(0, 255)):
    # range(0, 1)
    norm_img = (img - orig_range[0]) / (orig_range[1] - orig_range[0])
    # range(min_value, max_value)
    norm_img = norm_img * (norm_range[1] - norm_range[0]) + norm_range[0]
    return norm_img

def meanstd_normalize(img, mean, std):
    if img.shape[2] == 4:
        mean.append(0.)
        std.append(1.)
    mean = np.asarray(mean)
    std = np.asarray(std)
    norm_img = (img - mean) / std
    return norm_img

def quaternion_2_ypr(w, x, y, z):
    roll = math.atan2(2*(w*x + y*z), 1-2*(x*x + y*y))
    pitch = math.asin(2*(w*y - z*x))
    yaw = math.atan2(2*(w*z + y*x), 1-2*(z*z + y*y))

    roll = roll*180 / math.pi
    pitch = pitch*180 / math.pi
    yaw = yaw*180 / math.pi

    return [yaw, pitch, roll]

def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected')
